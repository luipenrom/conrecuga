<!-- CENTRAL -->
    <div class="caja">
        <div class="caja__titulo">
        </div>
        <div class="caja__textos">
            <table class="tabladatos">
                <tr>
                    <th>Usuario</th>
                    <th>Año</th>
                    <th>Total</th>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2010</td>
                    <td>32300.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Vicky</td>
                    <td>2010</td>
                    <td>14226.80 &#8364;</td>
                </tr>
                <tr>
                    <td>Vicky</td>
                    <td>2011</td>
                    <td>6247.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2011</td>
                    <td>2085.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2011</td>
                    <td>41.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2012</td>
                    <td>1500.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Vicky</td>
                    <td>2012</td>
                    <td>1550.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2012</td>
                    <td>2645.65 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2013</td>
                    <td>3566.32 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2013</td>
                    <td>2000.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2014</td>
                    <td>11179.06 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2014</td>
                    <td>2119.23 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2015</td>
                    <td>19084.70 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2015</td>
                    <td>11768.68 &#8364;</td>
                </tr>
                <tr>
                    <td>Conjunto</td>
                    <td>2016</td>
                    <td>3321.38 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2016</td>
                    <td>14700.00 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2017</td>
                    <td>5736.89 &#8364;</td>
                </tr>
                <tr>
                    <td>Luis</td>
                    <td>2023</td>
                    <td>220.09 &#8364;</td>
                </tr>
            </table>        
        </div>
    </div> 
</div>
