CREATE DATABASE IF NOT EXISTS conrecuga CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;

USE conrecuga;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Creo las tablas de roles y usuarios
--

CREATE TABLE `rol` (
  `id` int(11) AUTO_INCREMENT NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `usuarios` (
  `id` int(11) AUTO_INCREMENT NOT NULL,
  `nombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `grupo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `rol` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`rol`) REFERENCES `rol` (`id`)
);

--
-- Creamos las tablas iniciales de grupos. Las diferencio por categorías principales añadiendo al principio el texto datos
--

CREATE TABLE `datosingresos` (
  `id` int(11) AUTO_INCREMENT NOT NULL,
  `concepto` varchar(50) NOT NULL,
  `grupo` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `datosgastos` (
  `id` int(11) AUTO_INCREMENT NOT NULL,
  `concepto` varchar(50) NOT NULL,
  `grupo` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `datoscompras` (
  `id` int(11) AUTO_INCREMENT NOT NULL,
  `concepto` varchar(50) NOT NULL,
  `grupo` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

--
-- Creamos las tablas donde introduciremos los datos desde el sitio web. Las diferencio por categorías principales: ingresos, gastos y compras
--

CREATE TABLE `ingresos` (
  `id` int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
  `usuario` int(11) NOT NULL,
  `concepto` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `bruto` decimal(10,2) DEFAULT NULL,
  `irpf` decimal(10,2) DEFAULT NULL,
  `nota` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`id`),
  FOREIGN KEY (`concepto`) REFERENCES `datosIngresos` (`id`)
);

CREATE TABLE `gastos` (
  `id` int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
  `usuario` int(11) NOT NULL,
  `concepto` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `nota` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`id`),
  FOREIGN KEY (`concepto`) REFERENCES `datosGastos` (`id`)
);

CREATE TABLE `compras` (
  `id` int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
  `usuario` int(11) NOT NULL,
  `concepto` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `nota` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  KEY `usuario` (`usuario`),
  KEY `concepto` (`concepto`),
  FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`id`),
  FOREIGN KEY (`concepto`) REFERENCES `datosCompras` (`id`)
);

--
-- Insertamos datos generales
--

INSERT INTO `rol` (`id`, `nombre`, `descripcion`) VALUES
(1, 'administrador', 'Control total sobre la aplicacion'),
(2, 'gestor', 'Control de datos en el sistema'),
(3, 'editor', 'Puede introducir datos'),
(4, 'lector', 'Puede visitar la aplicación, con archivos de ejemplo');


INSERT INTO `datosgastos` (`id`, `concepto`, `grupo`, `imagen`)
VALUES
(1, 'kutxabank', 'hipoteca', 'kutxabank.png'),
(2, 'otros', 'hipoteca', 'otros.png'),
(5, 'hidraqua', 'agua', 'hidraqua.png'),
(6, 'IBI', 'casa', 'IBI.png'),
(7, 'basuras', 'casa', 'basuras.png'),
(8, 'comunidad', 'casa', 'comunidad.png'),
(9, 'otros', 'casa', 'otros.png'),
(11, 'iberdrola', 'luz', 'iberdrola.png'),
(12, 'cepsa', 'luz', 'cepsa.png'),
(13, 'repsol', 'luz', 'repsol.png'),
(19, 'otros', 'luz', 'otros.png'),
(21, 'simyo', 'telefonia', 'simyo.png'),
(22, 'avatel', 'telefonia', 'avatel.png'),
(23, 'telecable', 'telefonia', 'telecable.png'),
(29, 'otros', 'telefonia', 'otros.png'),
(31, 'kutxabank', 'seguros', 'kutxabank.png'),
(32, 'mapfre', 'seguros', 'mapfre.png'),
(39, 'otros', 'seguros', 'otros.png'),
(41, 'comedor', 'colegio', 'comedor.png'),
(42, 'extra_escolares', 'colegio', 'extra_escolares.png'),
(49, 'otros', 'colegio', 'otros.png'),
(51, 'volskwagen', 'coches', 'volskwagen.png'),
(52, 'serrauto', 'coches', 'serrauto.png'),
(53, 'maxi_auto', 'coches', 'maxi_auto.png'),
(54, 'otros_auto', 'coches', 'otros_auto.png'),
(59, 'otros', 'coches', 'otros.png'),
(61, 'prl', 'trabajo', 'prl.png'),
(62, 'uniformidad', 'trabajo', 'uniformidad.png'),
(63, 'salud', 'trabajo', 'salud.png'),
(64, 'formacion', 'trabajo', 'formacion.png'),
(65, 'comida', 'trabajo', 'comida.png'),
(69, 'otros', 'trabajo', 'otros.png'),
(81, 'prime', 'entretenimiento', 'prime.png'),
(82, 'netflix', 'entretenimiento', 'netflix.png'),
(83, 'disney', 'entretenimiento', 'disney.png'),
(84, 'hbo', 'entretenimiento', 'hbo.png'),
(89, 'otros', 'entretenimiento', 'otros.png'),
(99, 'otros', 'otros', 'otros.png');

INSERT INTO `datoscompras` (`id`, `concepto`, `grupo`, `imagen`)
VALUES
(1, 'dialprix', 'supermercado', 'dialprix.png'),
(2, 'lidl', 'supermercado', 'lidl.png'),
(3, 'mercadona', 'supermercado', 'mercadona.png'),
(4, 'aldi', 'supermercado', 'aldi.png'),
(5, 'consum', 'supermercado', 'consum.png'),
(6, 'udaco', 'supermercado', 'udaco.png'),
(7, 'dia', 'supermercado', 'dia.png'),
(8, 'spar', 'supermercado', 'spar.png'),
(9, 'otros', 'supermercado', 'otros.png'),
(21, 'carrefour', 'hipermercado', 'carrefour.png'),
(22, 'alcampo', 'hipermercado', 'alcampo.png'),
(23, 'ikea', 'hipermercado', 'ikea.png'),
(29, 'otros', 'hipermercado', 'otros.png'),
(31, 'leroym', 'brico', 'leroym.png'),
(32, 'bricoga', 'brico', 'bricoga.png'),
(33, 'bricodepot', 'brico', 'bricodepot.png'),
(39, 'otros', 'brico', 'otros.png'),
(41, 'burguerking', 'comida', 'burguerking.png'),
(42, 'mcdonalds', 'comida', 'mcdonalds.png'),
(43, 'tgb', 'comida', 'tgb.png'),
(49, 'otros', 'comida', 'otros.png'),
(51, 'megahogar', 'electronica', 'megahogar.png'),
(52, 'mediamarkt', 'electronica ', 'mediamarkt.png'),
(53, 'pccomponentes', 'electronica ', 'pccomponentes.png'),
(54, 'miniprice', 'electronica ', 'miniprice.png'),
(55, 'opirata', 'electronica ', 'opirata.png'),
(56, 'amazon', 'electronica ', 'amazon.png'),
(59, 'otros', 'electronica', 'otros.png'),
(61, 'primark', 'ropa', 'primark.png'),
(62, 'kiabi', 'ropa', 'kiabi.png'),
(63, 'hm', 'ropa', 'hm.png'),
(69, 'otros', 'ropa', 'otros.png'),
(71, 'juguetilandia', 'juguetes', 'juguetilandia.png'),
(72, 'dondino', 'juguetes', 'dondino.png'),
(73, 'panre', 'juguetes', 'panre.png'),
(74, 'toysrus', 'juguetes', 'toysrus.png'),
(75, 'carype', 'juguetes', 'carype.png'),
(76, 'playmycenter', 'juguetes', 'playmycenter.png'),
(79, 'otros', 'juguetes', 'otros.png'),
(81, 'lowcostga', 'gasolina', 'lowcostga.png'),
(82, 'repsol', 'gasolina', 'repsol.png'),
(83, 'cepsa', 'gasolina', 'cepsa.png'),
(84, 'bp', 'gasolina', 'bp.png'),
(85, 'petroalacant', 'gasolina', 'petroalacant.png'),
(89, 'otros', 'gasolina', 'otros.png'),
(91, 'zafirotours', 'viajes', 'zafirotours.png'),
(92, 'aparcamiento', 'viajes', 'aparcamiento.png'),
(94, 'otros', 'viajes', 'otros.png'),
(99, 'otros', 'otros', 'otros.png');

INSERT INTO `datosingresos` (`id`, `concepto`, `grupo`, `imagen`)
VALUES
(1, 'sueldo', 'regular', 'sueldo.png'),
(11, 'subvencion', 'puntual', 'subvencion.png'),
(12, 'beca', 'puntual', 'beca.png'),
(13, 'otros', 'puntual', 'otros.png'),
(21, 'trabajo', 'extra', 'trabajo.png'),
(22, 'compensacion', 'extra', 'compensacion.png'),
(23, 'otros', 'extra', 'otros.png');